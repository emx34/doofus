Doofus GBImageViewer 1.1a Design&CodeReverse by:EMX/PhRoZeNCReW'97 
Usage  : GBVIEW5 <file.dat> [palette.pal]
Example: GBVIEW5 0004_3f2.dat 

Types: A=block B=chunky C=raw D=chunky-zero E=actor-code(no display)
       F=tile-atlas (0007_237 credits/score screen, decoded+displayable)
.pal = 768-byte raw VGA palette (R,G,B + 256, values 0-63)

Known palettes (auto by comp size):
0004_3f2 (comp=9694)  = INLINE embedded (32 colors) Prestige GmbH logo
0005_3f2 (comp=18572) = GENERIC embedded (24 colors) Doofus game logo
0006_3f2 (comp=52670) = g_pal_0006 (256 colors), boy dog monkey elephant)
0008_3f2 (comp=10891) = g_pal_0008 (162 colors, highscore)
0062_3f2 (comp=9227)  = g_pal_0062 (106 colors, gameover)
others                = shared blue-ramp fallback
0025_237  = TYPE E actor sprite-code library (main character +
            companion animation). Detected/reported, NOT displayable.
0043-0054_3276 = 12-file level-background family (320x162). Palette
            unknown (see TYPE E / 0x3276 comments) -- pass a real
            .pal file for correct colours.
